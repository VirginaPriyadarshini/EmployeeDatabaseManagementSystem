package com.employee.Employee.Database.Management.System.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.Employee.Database.Management.System.Employee.Employee;
import com.employee.Employee.Database.Management.System.Exception.EmployeeException;
import com.employee.Employee.Database.Management.System.Repository.EmployeeRepository;


@Service
@Transactional
public class EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;
	
	 public List<Employee> getAllEmployees() throws EmployeeException {
	        return employeeRepository.findAll();
	    }
	     
	    public void post(Employee employee) throws EmployeeException {
	    	employeeRepository.save(employee);
	    }
	     
	    public Employee getEmployeeById(int id) throws EmployeeException{
	        return employeeRepository.findById(id).get();
	    }
	     
	    public void delete(int id) throws EmployeeException {
	    	employeeRepository.deleteById(id);
	    }

}
