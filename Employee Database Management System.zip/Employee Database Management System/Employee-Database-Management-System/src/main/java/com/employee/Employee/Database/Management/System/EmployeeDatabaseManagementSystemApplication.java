package com.employee.Employee.Database.Management.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDatabaseManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDatabaseManagementSystemApplication.class, args);
	}

}
